from tkinter import *
from playsound import playsound 
from threading import Thread

def music():playsound('resourses/amogus.mp3')

class Window:
    def __init__(self, width, height, title='App1', resizable=(False, False)):
        self.root = Tk()

        self.root.wm_attributes("-alpha", .30)

        self.root.title(title)
        self.root.geometry(f'{width}x{height}+200+200')
        self.root.resizable(resizable[0], resizable[1])
        self.label = Label(self.root, text="го в бравлик")
        self.amogus_image = PhotoImage(file=r'resourses/aue.png')
        self.label = Label(self.root, image=self.amogus_image)
    def run(self):
        self.draw_widgets()
        self.root.mainloop()

    def draw_widgets(self):
        self.label.pack(anchor=NE)


if __name__ == '__main__':
    window = Window(500, 550, 'AMOGUS')
    Thread(target = music, daemon=True).start()
    window.run()
